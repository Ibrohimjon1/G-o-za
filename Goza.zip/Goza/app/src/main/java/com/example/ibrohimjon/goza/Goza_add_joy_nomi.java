package com.example.ibrohimjon.goza;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class Goza_add_joy_nomi extends AppCompatActivity {

    AutoCompleteTextView auto_viloyat;
    AutoCompleteTextView auto_shahar;
    AutoCompleteTextView auto_kocha;
    Spinner spin_viloyat_nomi;
    Button btn_add, btn_goza_back_joy;
    ArrayList<String> list_viloyat, list_shahar, list_kocha;
    ArrayAdapter adapter_viloyat, adapter_shahar, adapter_kocha;
    String goza_intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.goza_add_joy_nomi);

//        auto_viloyat = (AutoCompleteTextView) findViewById(R.id.auto_viloyat);
        auto_shahar = (AutoCompleteTextView) findViewById(R.id.auto_shahar);
        auto_kocha = (AutoCompleteTextView) findViewById(R.id.auto_kocha);
        btn_add = (Button) findViewById(R.id.btn_goza_add_joy);
        spin_viloyat_nomi = (Spinner) findViewById(R.id.spin_viloyat_nomi);
        btn_goza_back_joy = (Button) findViewById(R.id.btn_goza_back_joy);

        Intent intent1 = getIntent();
        goza_intent = intent1.getExtras().getString("goza");

        list_viloyat = new ArrayList<>();
        list_shahar = new ArrayList<>();
        list_kocha = new ArrayList<>();

        btn_goza_back_joy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        list_viloyat.clear();
        list_viloyat.add("Andijon");
        list_viloyat.add("Buxoro");
        list_viloyat.add("Farg'ona");
        list_viloyat.add("Jizzax");
        list_viloyat.add("Xorazm");
        list_viloyat.add("Namangan");
        list_viloyat.add("Navoiy");
        list_viloyat.add("Qashqadaryo");
        list_viloyat.add("Qoraqalpog'iston");
        list_viloyat.add("Samarqand");
        list_viloyat.add("Sirdaryo");
        list_viloyat.add("Surxondaryo");
        list_viloyat.add("Toshkent");

        adapter_viloyat = new ArrayAdapter<>(this, android.R.layout.select_dialog_item, list_viloyat);
//        spin_viloyat_nomi.setThreshold(1);
        spin_viloyat_nomi.setAdapter(adapter_viloyat);

        Cursor cursor_shahar = Asosiy_oyna.myDataBase.getData("SELECT shahar FROM SHAHAR1");
        list_shahar.clear();
        while (cursor_shahar.moveToNext()) {
            String name = cursor_shahar.getString(0);
            list_shahar.add(name);
        }
        adapter_shahar = new ArrayAdapter<>(this, android.R.layout.select_dialog_item, list_shahar);
        auto_shahar.setThreshold(1);
        auto_shahar.setAdapter(adapter_shahar);

        Cursor cursor_kocha = Asosiy_oyna.myDataBase.getData("SELECT kocha FROM KOCHA");
        list_kocha.clear();
        while (cursor_kocha.moveToNext()) {
            String name = cursor_kocha.getString(0);
            list_kocha.add(name);
        }
        adapter_kocha = new ArrayAdapter<>(this, android.R.layout.select_dialog_item, list_kocha);
        auto_kocha.setThreshold(1);
        auto_kocha.setAdapter(adapter_kocha);

        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                String viloyat = auto_viloyat.getText().toString().trim();
                String shahar = auto_shahar.getText().toString().trim();
                String viloyat = spin_viloyat_nomi.getSelectedItem().toString();
                String kocha = auto_kocha.getText().toString().trim();

                if (!viloyat.equals("") && !shahar.equals("")) {
                    Cursor cursor = Asosiy_oyna.myDataBase.getData("SELECT * FROM VILOYAT WHERE viloyat LIKE '" + viloyat.replace("'", "''") + "'");

                    if (cursor.getCount() == 0) {
                        String sql = "INSERT INTO VILOYAT VALUES (NULL, ?)";
                        Asosiy_oyna.myDataBase.insert_shahar(viloyat, sql);
                    }

                    Cursor cursor1 = Asosiy_oyna.myDataBase.getData("SELECT * FROM SHAHAR1 WHERE shahar LIKE '" + shahar.replace("'", "''") + "'");
                    if (cursor1.getCount() == 0) {
                        String sql1 = "INSERT INTO SHAHAR1 VALUES (NULL, ?)";
                        Asosiy_oyna.myDataBase.insert_shahar(shahar, sql1);
                    }

                    Cursor cursor2 = Asosiy_oyna.myDataBase.getData("SELECT * FROM KOCHA WHERE kocha LIKE '" + kocha.replace("'", "''") + "'");
                    if (cursor2.getCount() == 0) {
                        String sql2 = "INSERT INTO KOCHA VALUES (NULL, ?)";
                        Asosiy_oyna.myDataBase.insert_shahar(kocha, sql2);
                    }
                    Intent intent = null;
                    assert goza_intent != null;
                    if (goza_intent.equals("goza")) {
                        intent = new Intent(Goza_add_joy_nomi.this, Goza_add.class);
                    } else if (goza_intent.equals("kuzgi")) {
                        intent = new Intent(Goza_add_joy_nomi.this, Kuzgi_add.class);
                    }

                    intent.putExtra("joy_nomi", "");
                    intent.putExtra("viloyat", viloyat);
                    intent.putExtra("shahar", shahar);
                    intent.putExtra("kocha", kocha);
                    startActivity(intent);
                    finish();
                } else {
                    if (auto_shahar.getText().toString().equals("")) {
                        auto_shahar.requestFocus();
                        Toast.makeText(getApplication(), "Iltimos Shahar nomini kiriting!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }


}
