package com.example.ibrohimjon.goza;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.NotificationCompat;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class Kuzgi_add extends AppCompatActivity {

    ImageView btn_add;
    GridLayout gridLayout;
    int year_x, month_x, day_x;
    int sana = 1;
    int indexx = 2;
    HorizontalScrollView scrollView;
    ArrayList<TextView> all_sana = new ArrayList<>();
    ArrayList<TextView> all_eskilar = new ArrayList<>();
    String string12 = "";
    TextView txt_saaana;
    TextView txt_sana_asosiy, txt_kop_asosiy, txt_foy_asosiy, txt_xaq_asosiy,
            txt_yig_asosiy, txt_goza_asosiy, txt_goza_add_joy;
    Button btn_goza_saqlash;
    String joy_nomi_intent = "";
    int yangi_add = 1;
    int qoshilgan_soni = 0;
    View row_asosiy;
    String oxir_yig = "", oxir_foy = "";
    RelativeLayout layout, layout1;
    TextView txt_bosh_txt;
    int ayrilgan_soni = 0;
    float ayir;
    int id = 0;
    private static Uri alarmSound;

    @TargetApi(Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.goza_add);

        txt_goza_add_joy = (TextView) findViewById(R.id.txt_goza_add_joy);
        gridLayout = (GridLayout) findViewById(R.id.gridlayout);
        txt_sana_asosiy = (TextView) findViewById(R.id.txt_sana_asosiy);
        btn_add = (ImageView) findViewById(R.id.btn_savdo_add_p);
        scrollView = (HorizontalScrollView) findViewById(R.id.scrollView);
        txt_kop_asosiy = (TextView) findViewById(R.id.txt_kop_asosiy);
        txt_foy_asosiy = (TextView) findViewById(R.id.txt_foy_asosiy);
        txt_xaq_asosiy = (TextView) findViewById(R.id.txt_xaq_asosiy);
        txt_yig_asosiy = (TextView) findViewById(R.id.txt_yig_asosiy);
        txt_goza_asosiy = (TextView) findViewById(R.id.txt_goza_asosiy);
        btn_goza_saqlash = (Button) findViewById(R.id.btn_goza_saqlash);
        layout = (RelativeLayout) findViewById(R.id.goza_layout);
        layout1 = (RelativeLayout) findViewById(R.id.goza_layout_q);
        txt_bosh_txt = (TextView) findViewById(R.id.txt_bosh_text);

        alarmSound = RingtoneManager
                .getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

        assert txt_bosh_txt != null;
        txt_bosh_txt.setText("Kuzgi tunlamning rivojlanish muddatlarini oldindan hisoblash jadvali");

        layout.setVisibility(View.GONE);
        layout1.setVisibility(View.GONE);

        Intent intent = getIntent();
        joy_nomi_intent = intent.getExtras().getString("joy_nomi");
        assert joy_nomi_intent != null;
        if (joy_nomi_intent.equals("")) {
            yangi_add = 1;
            final Calendar calendar = Calendar.getInstance();
            year_x = calendar.get(Calendar.YEAR);
            month_x = calendar.get(Calendar.MONTH);
            day_x = calendar.get(Calendar.DAY_OF_MONTH);

            SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy");
            string12 = format.format(calendar.getTime());
            txt_sana_asosiy.setText(string12);
            String viloyat = intent.getExtras().getString("viloyat");
            String shahar = intent.getExtras().getString("shahar");
            String kocha = intent.getExtras().getString("kocha");
            txt_goza_add_joy.setText(viloyat + "/" + shahar + "/" + kocha);
        } else {
            txt_goza_add_joy.setText(joy_nomi_intent);
            gridLayout.removeViewAt(1);
            final Calendar calendar = Calendar.getInstance();
            year_x = calendar.get(Calendar.YEAR);
            month_x = calendar.get(Calendar.MONTH);
            day_x = calendar.get(Calendar.DAY_OF_MONTH);
            indexx = 1;
            Toldirish();
            yangi_add = 0;
        }

        SharedPreferences preferences = getSharedPreferences("ortacha_xarorat", Context.MODE_PRIVATE);
        String goza = preferences.getString("kuzgi", "");
        if (!goza.equals("")) {
            ayir = Float.valueOf(goza);
        }
        txt_sana_asosiy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txt_saaana = txt_sana_asosiy;
                Sana_tanlash();
            }
        });

        txt_kop_asosiy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txt_OnClick(txt_kop_asosiy, 5);
            }
        });

        txt_xaq_asosiy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txt_OnClick(txt_xaq_asosiy, 8);
            }
        });

        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Qoshish();
            }
        });

    }

    public void txt_OnClick(TextView view, int qator) {
        String str = view.getText().toString();
        int id_txt = view.getId();
        showDialog_Update(Kuzgi_add.this, str, view, id_txt, qator);

    }

    public void txt_long_click(TextView textView, int qatot) {
        if (yangi_add == 0) {
            int id_txt = textView.getId();
            TextView textView1 = null;
            if (qatot == 1) {
                textView1 = all_eskilar.get(id_txt - 2);
            } else if (qatot == 2) {
                textView1 = all_eskilar.get(id_txt - 3);
            } else if (qatot == 3) {
                textView1 = all_eskilar.get(id_txt - 4);
            } else if (qatot == 4) {
                textView1 = all_eskilar.get(id_txt - 5);
            } else if (qatot == 5) {
                textView1 = all_eskilar.get(id_txt - 6);
            } else if (qatot == 6) {
                textView1 = all_eskilar.get(id_txt - 7);
            }
            int farq = id_txt / 7;
            if ((farq + 2) == indexx) {
                assert textView1 != null;
                String qator_id = textView1.getText().toString();
                showDialogDelete_for_one(qator_id, (farq + 2));
            } else {
                Toast.makeText(getApplicationContext(), "Iltimos oxirgi ma'lumotni o'chiring!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void showDialogDelete_for_one(final String id, final int indeeex) {
        AlertDialog.Builder dialogDelete = new AlertDialog.Builder(Kuzgi_add.this);
        dialogDelete.setTitle("Ogohlantirish!!!");
        dialogDelete.setMessage("Haqiqatdan ham ushbu ma'lumotni o'chirmoqchimisiz?");
        dialogDelete.setPositiveButton("O'chirish", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                try {
                    Asosiy_oyna.myDataBase.insert_shahar(id, "DELETE FROM KUZGI WHERE Id = ?");
                    Toast.makeText(getApplicationContext(), "Muvaffaqqiyatli o'chirildi!!!", Toast.LENGTH_SHORT).show();
                } catch (Exception error) {
                    error.printStackTrace();
                }
                gridLayout.removeViewAt(indeeex - 1);
                Cursor cursor_goza = Asosiy_oyna.myDataBase.getData("SELECT * FROM KUZGI WHERE joy_nomi LIKE '" + joy_nomi_intent.replace("'", "''") + "' ORDER BY DATE(sana) ASC");
                if (cursor_goza.getCount() != 0) {
                    cursor_goza.moveToLast();
                    string12 = cursor_goza.getString(1);
                    oxir_foy = cursor_goza.getString(3);
                    oxir_yig = cursor_goza.getString(5);
                }
                int sons = all_eskilar.size() - 1;
                for (int i = 1; i < 8; i++) {
                    all_eskilar.remove(sons);
                    sons--;
                    sana--;
                    qoshilgan_soni--;
                }
                ayrilgan_soni++;
                indexx -= 1;
            }
        });

        dialogDelete.setNegativeButton("Yo'q", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        dialogDelete.show();
    }

    private void showDialogDelete_yangi() {
        AlertDialog.Builder dialogDelete = new AlertDialog.Builder(Kuzgi_add.this);
        dialogDelete.setTitle("Ogohlantirish!!!");
        dialogDelete.setMessage("Haqiqatdan ham ushbu ma'lumotni o'chirmoqchimisiz?");
        dialogDelete.setPositiveButton("O'chirish", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                gridLayout.removeViewAt(indexx - 1);
                string12 = Oldingi_sana(string12);
                int soni = sana - all_eskilar.size() - 2;
                for (int i = 1; i < 7; i++) {
                    all_sana.remove(soni);
                    soni--;
                    sana--;
                }

                indexx -= 1;
            }
        });

        dialogDelete.setNegativeButton("Yo'q", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        dialogDelete.show();
    }

    public void txt_long_click_yangi(TextView textView, int qator) {
        if (yangi_add == 0) {
            int id_txt = textView.getId();
            int farq = id_txt / 6;
            if ((farq + 2) == indexx) {
                showDialogDelete_yangi();
            } else {
                Toast.makeText(getApplicationContext(), "Iltimos oxirgi ma'lumotni o'chiring!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void Toldirish() {
        try {
            Cursor cursor_goza = Asosiy_oyna.myDataBase.getData("SELECT * FROM KUZGI WHERE joy_nomi LIKE '" + joy_nomi_intent.replace("'", "''") + "' ORDER BY DATE(sana) ASC");
            if (cursor_goza.getCount() != 0) {
                cursor_goza.moveToFirst();
                do {
                    int id = cursor_goza.getInt(0);
                    String sana = cursor_goza.getString(1);
                    String kop = cursor_goza.getString(2);
                    String foy = cursor_goza.getString(3);
                    String xaq = cursor_goza.getString(4);
                    String yig = cursor_goza.getString(5);
                    String goza = cursor_goza.getString(6);

                    Qoshish_update(id, sana, kop, foy, xaq, yig, goza);

                } while (cursor_goza.moveToNext());

                cursor_goza.moveToLast();
                qoshilgan_soni = cursor_goza.getCount() * 7;
                string12 = cursor_goza.getString(1);
                oxir_foy = cursor_goza.getString(3);
                oxir_yig = cursor_goza.getString(5);
            }
        } catch (Exception error) {
            error.printStackTrace();

        }
    }

    public void Saqlash() {

        String joy_nomi = txt_goza_add_joy.getText().toString().trim();
        String sql = "INSERT INTO KUZGI VALUES (NULL, ?, ?, ?, ?, ?, ?, ?)";

        if (!txt_kop_asosiy.getText().toString().equals("") || !txt_xaq_asosiy.getText().toString().equals("")) {
            String sana = txt_sana_asosiy.getText().toString().trim();
            String kop_yillik = txt_kop_asosiy.getText().toString().trim();
            String foydali = txt_foy_asosiy.getText().toString().trim();
            String xaqiq = txt_xaq_asosiy.getText().toString().trim();
            String yigin = txt_yig_asosiy.getText().toString().trim();
            String goza = txt_goza_asosiy.getText().toString().trim();

            try {
                Asosiy_oyna.myDataBase.Insert_goza(sana, kop_yillik, foydali, xaqiq, yigin, goza, joy_nomi, sql);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        try {
            if (all_sana.size() > 0) {
                int a = (all_sana.size() + 1) / 6;
                int id = 0;
                for (int i = 0; i < a; i++) {
                    TextView txt_sana = all_sana.get(id);
                    id++;
                    TextView txt_kop = all_sana.get(id);
                    id++;
                    TextView txt_foy = all_sana.get(id);
                    id++;
                    TextView txt_xaq = all_sana.get(id);
                    id++;
                    TextView txt_yig = all_sana.get(id);
                    id++;
                    TextView txt_goza = all_sana.get(id);
                    id++;

                    String str_sana = txt_sana.getText().toString().trim();
                    String str_kop = txt_kop.getText().toString().trim();
                    String str_foy = txt_foy.getText().toString().trim();
                    String str_xaq = txt_xaq.getText().toString().trim();
                    String str_yig = txt_yig.getText().toString().trim();
                    String str_goza = txt_goza.getText().toString().trim();
                    if (!str_kop.equals("") && !str_xaq.equals("")) {
                        Asosiy_oyna.myDataBase.Insert_goza(str_sana, str_kop, str_foy, str_xaq, str_yig, str_goza, joy_nomi, sql);
                    }
                }
                all_sana.clear();
            }

            Toast.makeText(getApplicationContext(), "Muvaffaqqiyatli saqlandi!", Toast.LENGTH_SHORT).show();
            finish();
        } catch (Exception error) {
            error.printStackTrace();
            Toast.makeText(getApplicationContext(), "Saqlanishda xatolik bo'ldi!!!", Toast.LENGTH_SHORT).show();
        }

    }

    public boolean onCreateOptionsMenu(Menu menu) {
        // tepada menu tugmalari qo'shish
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_add) {
            Saqlash();
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        showDialog_exit_yangi();
    }

    private void showDialog_exit_yangi() {
        AlertDialog.Builder dialogDelete = new AlertDialog.Builder(Kuzgi_add.this);
        dialogDelete.setTitle("Ogohlantirish!!!");
        dialogDelete.setMessage("O'zgartirishlarni saqlaysizmi?");
        dialogDelete.setPositiveButton("Ha", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                Saqlash();
            }
        });

        dialogDelete.setNegativeButton("Yo'q", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                finish();
            }
        });
        dialogDelete.show();
    }

    private void showDialog_Update(Activity activity, final String kirim_nomi, final TextView textView, final int kegingi, final int qator) {
//        final float[] faa = new float[1];
        final Dialog dialog = new Dialog(activity);
        dialog.setContentView(R.layout.raqam_oyna);
        dialog.setCancelable(false);
        dialog.setTitle("O'zgartirish");

        TextView txt_oyna_upd = (TextView) dialog.findViewById(R.id.txt_oyna_nom);

        if (qator == 1 || qator == 5) {
            txt_oyna_upd.setText("Ko'p yillik o'rtacha harorat");
        } else if (qator == 2 || qator == 8) {
            txt_oyna_upd.setText("Xaqiqiy o'rtacha harorat");
        }

        Button btn_oyna_back = (Button) dialog.findViewById(R.id.btn_oyna_back);
        Button btn_oyna_update = (Button) dialog.findViewById(R.id.btn_oyna_add);
        final EditText edt_oyna_upd = (EditText) dialog.findViewById(R.id.edt_oyna_xarorat);

        btn_oyna_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!edt_oyna_upd.getText().toString().equals("")) {
                    float aa = Float.valueOf(edt_oyna_upd.getText().toString());
                    textView.setText(String.valueOf(aa));
                    if (yangi_add == 1) {
                        if (qator == 1) {
                            int qaysi = all_sana.size() / 6;
                            if (!(qaysi >= 1)) {
                                if (!txt_foy_asosiy.getText().toString().equals("")) {
                                    float a_oldingi = Float.valueOf(txt_foy_asosiy.getText().toString());
                                    aa = (aa - ayir) + a_oldingi;
                                } else {
                                    aa = (aa - ayir);
                                }
                                TextView textView = all_sana.get(kegingi);
                                textView.setText(String.valueOf(roundUp(aa, 1)));
                                dialog.dismiss();
                            } else {
                                int asf = kegingi - 6;
                                TextView textView_oldingi, txt_olding;
                                if (asf < 0) {
                                    textView_oldingi = all_sana.get(asf * (-1));
                                    txt_olding = all_sana.get(asf * (-1) - 1);
                                } else {
                                    textView_oldingi = all_sana.get(asf);
                                    txt_olding = all_sana.get(asf - 1);
                                }
                                float a_oldingi = 0;
                                float old_s = 0;
                                String old_son = txt_olding.getText().toString();
                                if (!old_son.equals("")) {
                                    try {
                                        old_s = Float.parseFloat(old_son);
                                    } catch (NumberFormatException e) {
                                        e.printStackTrace();
                                    }
                                }
                                if (!textView_oldingi.getText().toString().equals("")) {
                                    a_oldingi = Float.valueOf(textView_oldingi.getText().toString());
                                }
                                if (aa < old_s) {
                                    aa = a_oldingi;
                                } else {
                                    if (a_oldingi != 0) {
                                        aa = (aa - ayir) + a_oldingi;
                                    } else {
                                        aa = (aa - ayir);
                                    }
                                }
                                String son = String.valueOf(roundUp(aa, 1));
                                Xabar_chiqarish(son);

                                TextView textView = all_sana.get(kegingi);
                                textView.setText(son);
                                dialog.dismiss();
                            }
                        } else if (qator == 2) {
                            int qaysi = all_sana.size() / 6;
                            if (!(qaysi > 1)) {
                                if (!txt_foy_asosiy.getText().toString().equals("")) {
                                    float a_oldingi = Float.valueOf(txt_foy_asosiy.getText().toString());
                                    aa = (aa - ayir) + a_oldingi;
                                } else {
                                    aa = (aa - ayir);
                                }
                                String son = String.valueOf(roundUp(aa, 1));
                                Xabar_chiqarish(son);
                                TextView textView = all_sana.get(kegingi);
                                textView.setText(String.valueOf(roundUp(aa, 1)));
                                TextView textView2 = all_sana.get(kegingi + 1);
                                textView2.setText(String.valueOf(roundUp(aa, 1)));
                                dialog.dismiss();
                            } else {
                                int asf = kegingi - 6;
                                TextView textView_oldingi, txt_olding;
                                if (asf < 0) {
                                    textView_oldingi = all_sana.get(asf * (-1));
                                    txt_olding = all_sana.get(asf * (-1) - 1);
                                } else {
                                    textView_oldingi = all_sana.get(asf);
                                    txt_olding = all_sana.get(asf - 1);
                                }
                                float a_oldingi = 0;
                                float old_s = 0;
                                String old_son = txt_olding.getText().toString();
                                if (!old_son.equals("")) {
                                    try {
                                        old_s = Float.parseFloat(old_son);
                                    } catch (NumberFormatException e) {
                                        e.printStackTrace();
                                    }
                                }
                                if (!textView_oldingi.getText().toString().equals("")) {
                                    a_oldingi = Float.valueOf(textView_oldingi.getText().toString());
                                }
                                if (aa < old_s) {
                                    aa = a_oldingi;
                                } else {
                                    if (a_oldingi != 0) {
                                        aa = (aa - ayir) + a_oldingi;
                                    } else {
                                        aa = (aa - ayir);
                                    }
                                }
                                TextView textView = all_sana.get(kegingi);
                                textView.setText(String.valueOf(roundUp(aa, 1)));
                                String son = String.valueOf(roundUp(aa, 1));
                                Xabar_chiqarish(son);
                                TextView textView2 = all_sana.get(kegingi + 1);
                                textView2.setText(String.valueOf(roundUp(aa, 1)));
                                dialog.dismiss();
                            }
                        } else {
                            if (qator == 5) {
                                txt_foy_asosiy.setText("0");
                                Xabar_chiqarish("0");
                                dialog.dismiss();
                            } else {
                                txt_yig_asosiy.setText("0");
                                txt_goza_asosiy.setText("0");
                                Xabar_chiqarish("0");
                                dialog.dismiss();
                            }
                        }
                    } else {
                        if (qator == 1) {
                            int qaysi = all_sana.size() / 7;
                            if (!(qaysi >= 1)) {
                                if (!oxir_foy.equals("")) {
                                    float a_oldingi = Float.valueOf(oxir_foy);
                                    aa = (aa - ayir) + a_oldingi;
                                } else {
                                    aa = (aa - ayir);
                                }

                                String son = String.valueOf(roundUp(aa, 1));
                                Xabar_chiqarish(son);
                                TextView textView = all_sana.get(kegingi - qoshilgan_soni);
                                textView.setText(son);
                                dialog.dismiss();

                            } else {
                                int asf = kegingi - qoshilgan_soni - 6;
                                TextView textView_oldingi, txt_olding;
                                if (asf < 0) {
                                    textView_oldingi = all_sana.get(asf * (-1));
                                    txt_olding = all_sana.get(asf * (-1) - 1);
                                } else {
                                    textView_oldingi = all_sana.get(asf);
                                    txt_olding = all_sana.get(asf - 1);
                                }
                                float a_oldingi = 0;
                                float old_s = 0;
                                String old_son = txt_olding.getText().toString();
                                if (!old_son.equals("")) {
                                    try {
                                        old_s = Float.parseFloat(old_son);
                                    } catch (NumberFormatException e) {
                                        e.printStackTrace();
                                    }
                                }
                                if (!textView_oldingi.getText().toString().equals("")) {
                                    a_oldingi = Float.valueOf(textView_oldingi.getText().toString());
                                }
                                if (aa < old_s) {
                                    aa = a_oldingi;
                                } else {
                                    if (a_oldingi != 0) {
                                        aa = (aa - ayir) + a_oldingi;
                                    } else {
                                        aa = (aa - ayir);
                                    }
                                }
                                String son = String.valueOf(roundUp(aa, 1));
                                Xabar_chiqarish(son);
                                TextView textView = all_sana.get(kegingi - qoshilgan_soni);
                                textView.setText(son);
                                dialog.dismiss();
                            }
                        } else if (qator == 2) {
                            int qaysi = all_sana.size() / 7;
                            if (!(qaysi >= 1)) {
                                if (!oxir_yig.equals("")) {
                                    float a_oldingi = Float.valueOf(oxir_yig);
                                    aa = (aa - ayir) + a_oldingi;
                                } else {
                                    aa = (aa - ayir);
                                }
                                String son = String.valueOf(roundUp(aa, 1));
                                Xabar_chiqarish(son);
                                TextView textView = all_sana.get(kegingi - qoshilgan_soni);
                                textView.setText(String.valueOf(roundUp(aa, 1)));
                                TextView textView2 = all_sana.get(kegingi - qoshilgan_soni + 1);
                                textView2.setText(String.valueOf(roundUp(aa, 1)));
                                dialog.dismiss();
                            } else {
                                int asf = kegingi - qoshilgan_soni - 6;
                                TextView textView_oldingi, txt_olding;
                                if (asf < 0) {
                                    textView_oldingi = all_sana.get(asf * (-1));
                                    txt_olding = all_sana.get(asf * (-1) - 1);
                                } else {
                                    textView_oldingi = all_sana.get(asf);
                                    txt_olding = all_sana.get(asf - 1);
                                }
                                float a_oldingi = 0;
                                float old_s = 0;
                                String old_son = txt_olding.getText().toString();
                                if (!old_son.equals("")) {
                                    try {
                                        old_s = Float.parseFloat(old_son);
                                    } catch (NumberFormatException e) {
                                        e.printStackTrace();
                                    }
                                }
                                if (!textView_oldingi.getText().toString().equals("")) {
                                    a_oldingi = Float.valueOf(textView_oldingi.getText().toString());
                                }
                                if (aa < old_s) {
                                    aa = a_oldingi;
                                } else {
                                    if (a_oldingi != 0) {
                                        aa = (aa - ayir) + a_oldingi;
                                    } else {
                                        aa = (aa - ayir);
                                    }
                                }
                                TextView textView = all_sana.get(kegingi - qoshilgan_soni);
                                textView.setText(String.valueOf(roundUp(aa, 1)));
                                String son = String.valueOf(roundUp(aa, 1));
                                Xabar_chiqarish(son);
                                TextView textView2 = all_sana.get(kegingi + 1 - qoshilgan_soni);
                                textView2.setText(String.valueOf(roundUp(aa, 1)));
                                dialog.dismiss();
                            }
                        }
                    }
                }
            }
        });

        btn_oyna_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        int width = activity.getResources().getDisplayMetrics().widthPixels;
        int height = (int) (activity.getResources().getDisplayMetrics().heightPixels);

        dialog.getWindow().setLayout(width, height);
        dialog.show();

    }

    public BigDecimal roundUp(double value, int digits) {
        return new BigDecimal("" + value).setScale(digits, BigDecimal.ROUND_HALF_UP);
    }

    public void Sana_tanlash() {
        DatePickerDialog datePickerDialog = new DatePickerDialog(this, dpickerListener, year_x, month_x, day_x);
        datePickerDialog.show();
    }

    private DatePickerDialog.OnDateSetListener dpickerListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(android.widget.DatePicker view, int year, int monthOfYear, int dayOfMonth) {
            String oy, kun;
            if (monthOfYear < 10) {
                oy = "0" + String.valueOf(monthOfYear + 1) + ".";
            } else {
                oy = String.valueOf(monthOfYear + 1) + ".";
            }
            if (dayOfMonth < 10) {
                kun = "0" + String.valueOf(dayOfMonth) + ".";
            } else {
                kun = String.valueOf(dayOfMonth) + ".";
            }
            string12 = kun.toString() + oy.toString() + String.valueOf(year);
            txt_saaana.setText(string12);
        }
    };

    public void Xabar_chiqarish(String son) {

        SharedPreferences preferences = getSharedPreferences("setting", Context.MODE_PRIVATE);

        String goza = preferences.getString("xabar", "1");
        if (goza.equals("1")) {

            int son_solish = (int) Float.parseFloat(son);
            if (son_solish > 80 && son_solish < 100) {
                Xabar_korsatish("100 ga yetganda 1- avlod tuxum qo'yadi!");
            } else if (son_solish > 170 && son_solish < 200) {
                Xabar_korsatish("200 ga yetganda 2 yosh qurtlari!");
            } else if (son_solish > 270 && son_solish < 300) {
                Xabar_korsatish("300 ga yetganda 4 yosh qurtlari!");
            } else if (son_solish > 360 && son_solish < 400) {
                Xabar_korsatish("400 ga yetganda 6 yosh qurtlari!");
            } else if (son_solish > 500 && son_solish < 550) {
                Xabar_korsatish("550 ga yetganda rivojlanish tugadi!");
            } else if (son_solish > 570 && son_solish < 600) {
                Xabar_korsatish("600 ga yetganda 2-avlod tuxum qo'yadi!");
            } else if (son_solish > 650 && son_solish < 700) {
                Xabar_korsatish("700 ga yetganda 2 yosh qurtlari!");
            } else if (son_solish > 750 && son_solish < 800) {
                Xabar_korsatish("800 ga yetganda 4 yosh qurtlari!");
            } else if (son_solish > 850 && son_solish < 900) {
                Xabar_korsatish("900 ga yetganda 6 yosh qurtlari!");
            } else if (son_solish > 1000 && son_solish < 1050) {
                Xabar_korsatish("1050 ga yetganda rivojlanish tugadi!");
            } else if (son_solish > 1070 && son_solish < 1100) {
                Xabar_korsatish("1100 ga yetganda 3-avlod tuxum qo'yadi!");
            } else if (son_solish > 1150 && son_solish < 1200) {
                Xabar_korsatish("1200 ga yetganda 2 yosh qurtlari");
            } else if (son_solish > 1250 && son_solish < 1300) {
                Xabar_korsatish("1300 ga yetganda 4 yosh qurtlari");
            } else if (son_solish > 1350 && son_solish < 1400) {
                Xabar_korsatish("1400 ga yetganda 6 yosh qurtlari");
            } else if (son_solish > 1500 && son_solish < 1550) {
                Xabar_korsatish("1550 ga yetganda rivojlanish tugadi!");
            } else if (son_solish == 0) {
                Xabar_korsatish("Doimo birinchi qiymat 0 bo'ladi!");
            }
        }
    }

    Context context = Kuzgi_add.this;

    public void Xabar_korsatish(String xabar) {

        NotificationCompat.Builder mBuilder = (NotificationCompat.Builder) new NotificationCompat.Builder(this)
                .setSmallIcon(R.drawable.kuzgiic)
                .setContentTitle("G'o'za va kuzgi tunlami")
                .setContentText(xabar)
                .setSound(alarmSound)
                .setLargeIcon(BitmapFactory.decodeResource(context.getResources(),
                        R.drawable.kuzgi_32))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);
        id++;
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        notificationManager.notify(id, mBuilder.build());

        final AlertDialog.Builder adb = new AlertDialog.Builder(this);
        adb.setMessage(xabar);
        adb.setIcon(R.drawable.kuzgi_32);
        adb.setTitle("Ogohlantirish");
        adb.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
            }
        });
        adb.show();
    }

    public void Qoshish_update(int id, String sana_, String kop, String foy, String xaq, String yig, String goza) {

        LayoutInflater inflater = (LayoutInflater) Kuzgi_add.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        row_asosiy = inflater.inflate(R.layout.goza_add_items, null);

        RelativeLayout layout = (RelativeLayout) row_asosiy.findViewById(R.id.goza_item_layout);
        layout.setVisibility(View.GONE);

        TextView txt_goza_id = (TextView) row_asosiy.findViewById(R.id.txt_goza_id);
        txt_goza_id.setId(sana);
        txt_goza_id.setText(String.valueOf(id));

        all_eskilar.add(txt_goza_id);
        sana++;

        final TextView txt_sana = (TextView) row_asosiy.findViewById(R.id.txt_sana);
        txt_sana.setId(sana);
        txt_sana.setText(sana_);
        txt_sana.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                txt_long_click(txt_sana, 1);
                return true;
            }
        });
        all_eskilar.add(txt_sana);
        sana++;

        final TextView txt_kop = (TextView) row_asosiy.findViewById(R.id.txt_kop);
        txt_kop.setId(sana);
        txt_kop.setText(kop);
        txt_kop.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                txt_long_click(txt_kop, 2);
                return true;
            }
        });
        all_eskilar.add(txt_kop);
        sana++;

        final TextView txt_foy = (TextView) row_asosiy.findViewById(R.id.txt_foy);
        txt_foy.setText(foy);
        txt_foy.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                txt_long_click(txt_foy, 3);
                return true;
            }
        });
        all_eskilar.add(txt_foy);
        sana++;

        final TextView txt_xaq = (TextView) row_asosiy.findViewById(R.id.txt_xaq);
        txt_xaq.setId(sana);
        txt_xaq.setText(xaq);
        txt_xaq.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                txt_long_click(txt_xaq, 4);
                return true;
            }
        });
        all_eskilar.add(txt_xaq);
        sana++;

        final TextView txt_yig = (TextView) row_asosiy.findViewById(R.id.txt_yig);
        txt_yig.setId(sana);
        txt_yig.setText(yig);
        txt_yig.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                txt_long_click(txt_yig, 5);
                return true;
            }
        });
        all_eskilar.add(txt_yig);
        sana++;

        final TextView txt_goza = (TextView) row_asosiy.findViewById(R.id.txt_goza);
        txt_goza.setId(sana);
        txt_goza.setText(goza);
        txt_goza.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                txt_long_click(txt_goza, 6);
                return true;
            }
        });
        all_eskilar.add(txt_goza);
        sana++;

        gridLayout.addView(row_asosiy, indexx);
        indexx++;
    }

    public void Qoshish() {
        View row;
        LayoutInflater inflater = (LayoutInflater) Kuzgi_add.this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        row = inflater.inflate(R.layout.goza_add_items, null);

        RelativeLayout layout = (RelativeLayout) row.findViewById(R.id.goza_item_layout);
        layout.setVisibility(View.GONE);

        final TextView txt_sana = (TextView) row.findViewById(R.id.txt_sana);
        txt_sana.setId(sana);
        if (!string12.equals("")) {
            string12 = Kegingi_sana(string12);
        }
        txt_sana.setText(string12);
        txt_sana.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txt_saaana = txt_sana;
                Sana_tanlash();
            }
        });
        txt_sana.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                txt_long_click_yangi(txt_sana, 1);
                return true;
            }
        });

        all_sana.add(txt_sana);
        sana++;


        final TextView txt_kop = (TextView) row.findViewById(R.id.txt_kop);
        txt_kop.setId(sana);
        txt_kop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txt_OnClick(txt_kop, 1);
            }
        });
        txt_kop.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                txt_long_click_yangi(txt_kop, 2);
                return true;
            }
        });
        txt_kop.requestFocus();
        all_sana.add(txt_kop);
        sana++;

        final TextView txt_foy = (TextView) row.findViewById(R.id.txt_foy);
        txt_foy.setId(sana);
        all_sana.add(txt_foy);
        txt_foy.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                txt_long_click_yangi(txt_foy, 3);
                return true;
            }
        });
        sana++;

        final TextView txt_xaq = (TextView) row.findViewById(R.id.txt_xaq);
        txt_xaq.setId(sana);
        txt_xaq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txt_OnClick(txt_xaq, 2);
            }
        });
        txt_xaq.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                txt_long_click_yangi(txt_xaq, 4);
                return true;
            }
        });
        sana++;
        all_sana.add(txt_xaq);

        final TextView txt_yig = (TextView) row.findViewById(R.id.txt_yig);
        txt_yig.setId(sana);
        sana++;
        txt_yig.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                txt_long_click_yangi(txt_yig, 5);
                return true;
            }
        });
        all_sana.add(txt_yig);

        final TextView txt_goza = (TextView) row.findViewById(R.id.txt_goza);
        txt_goza.setId(sana);
        sana++;
        txt_goza.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                txt_long_click_yangi(txt_goza, 6);
                return true;
            }
        });
        all_sana.add(txt_goza);

        gridLayout.addView(row, indexx);

        scrollView.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (indexx > 4) {
                    scrollView.fullScroll(HorizontalScrollView.FOCUS_RIGHT);
                }
            }
        }, 100L);
        indexx++;
    }

    public String Kegingi_sana(String old_date) {

        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
        Calendar c = Calendar.getInstance();
        try {
            c.setTime(sdf.parse(old_date));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        //Incrementing the date by 1 day
        c.add(Calendar.DAY_OF_MONTH, 1);
        return sdf.format(c.getTime());
    }

    public String Oldingi_sana(String old_date) {

        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
        Calendar c = Calendar.getInstance();
        try {
            c.setTime(sdf.parse(old_date));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        //Incrementing the date by 1 day
        c.add(Calendar.DAY_OF_MONTH, -1);
        return sdf.format(c.getTime());
    }
}
